<?php
class person{
	public $name;

	function show(){
		echo "Your Name :".$this->name;
	}
}

$p1=new person();
$p1->name="Ajeet";
echo $p1->show();
echo "<br>";

$p2=new person();
$p2->name="Vishal";
echo $p2->show();

?>