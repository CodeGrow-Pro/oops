<!DOCTYPE html>
<html>
<head>
	<title>Insert</title>
</head>
<body>
	<form method="post">
<table border="1" width="40%" align="center" cellpadding="5" cellspacing="0">
	<tr>
		<th colspan="2">Student Record </th>
	</tr>
	<tr>
		<th>Name</th>
		<td><input type="text" name="name" placeholder="Enter Your Name" required=""></td>
	</tr>
	<tr>
		<th>Email</th>
		<td><input type="email" name="email" placeholder="Enter Your Email" required=""></td>
	</tr>
	<tr>
		<th>Mobile</th>
		<td><input type="text" name="mobile" placeholder="Enter Your Mobile" required=""></td>
	</tr>
	<tr>
		<th>Message</th>
		<td><textarea name="message" cols="24" rows="3"></textarea></td>
	</tr>
	<tr>
		<th colspan="2"><input type="submit" name="Submit" value="Submit"></th>
	</tr>
</table>
</form>
</body>
</html>
<?php
include('db.php');
if(isset($_POST['Submit']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$message=$_POST['message'];

	$query="Insert into student(name,email,mobile,message)values('$name','$email','$mobile','$message')";
	$result=mysqli_query($conn,$query);
	if($result)
	{
		echo "<script>alert('Student Record Save Successfully!');</script>";
	}else{
		echo "<script>alert('Student Record Failed!');</script>";
	}
}

?>