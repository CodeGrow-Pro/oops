<!DOCTYPE html>
<html>
<head>
	<title>Display Record</title>
</head>
<body>
<table border="1" width="90%" align="center" cellpadding="5" cellspacing="0">
	<tr>
		<th colspan="6">Student Record Display </th>
	</tr>
	<tr>
		<th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Message</th>
        <th>Action</th>
	</tr>
	<?php
	include('db.php');
      $sql="SELECT * FROM student ORDER BY id DESC;";
    $run = mysqli_query($conn,$sql);
    while ($user = mysqli_fetch_assoc($run)){
     ?>
	<tr align="center">
		<td><?php echo $user['id']  ?></td>
        <td><?php echo $user['name']  ?></td>
        <td><?php echo $user['email']  ?></td>
        <td><?php echo $user['mobile']  ?></td>
        <td><?php echo $user['message']  ?></td>
        <td><a href="#">Update</a> | <a href="#">Delete</a></td>
	</tr>
	 <?php 	
      }
	?>
</table>
</body>
</html>