<?php
include('db.php');
// Student Record Fetch Data
if(isset($_GET['update_id']))
{
	$id=$_GET['update_id'];
	$sql="SELECT * FROM student where id='$id'";
	$run=mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($run);
	//echo $user['name'];
}
// Student Record Update
if(isset($_POST['Update']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$message=$_POST['message'];

	$sqlu="UPDATE student SET name='$name',email='$email',mobile='$mobile',message='$message' where id='$id'";
	$result=mysqli_query($conn,$sqlu);
	if($result){
		echo "<script>alert('Student Record Update!');</script>";
		header('refresh:.5; url=display.php');
	}else
	{
		echo "<script>alert('Student Record Failed!');</script>";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Update</title>
</head>
<body>
	<form method="post">
<table border="1" width="40%" align="center" cellpadding="5" cellspacing="0">
	<tr>
		<th colspan="2">Student Update </th>
	</tr>
	<tr>
		<th>Name</th>
		<td><input type="text" name="name" placeholder="Enter Your Name" value="<?php echo $user['name'];?>"></td>
	</tr>
	<tr>
		<th>Email</th>
		<td><input type="email" name="email" placeholder="Enter Your Email" value="<?php echo $user['email'];?>"></td>
	</tr>
	<tr>
		<th>Mobile</th>
		<td><input type="text" name="mobile" placeholder="Enter Your Mobile" value="<?php echo $user['mobile'];?>"></td>
	</tr>
	<tr>
		<th>Message</th>
		<td><textarea name="message" cols="24" rows="3"><?php echo $user['message'];?></textarea></td>
	</tr>
	<tr>
		<th colspan="2"><input type="submit" name="Update" value="Update"></th>
	</tr>
</table>
</form>
</body>
</html>
