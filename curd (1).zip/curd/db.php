<?php
$hostname="localhost";
$usernmae="root";
$password="";
$dbname="vishalcurd";

$conn=mysqli_connect($hostname,$usernmae,$password,$dbname);
if(!$conn){
	echo "Data base is not Connect";
}
?>