<?php
class calculater{
	public $a, $b, $c;
	
	function sum(){
		$this->c=$this->a+$this->b;
		return $this->c;
	}
	function sub(){
		$this->c=$this->a-$this->b;
		return $this->c;
	}
}

$c1=new calculater;
$c1->a=20;
$c1->b=10;
echo "Sum".$c1->sum();
echo "<br>";
echo "Sub".$c1->sub();
echo "<br>";

$c2=new calculater;
$c2->a=50;
$c2->b=20;
echo "Sum".$c2->sum();
echo "<br>";
echo "Sub".$c2->sub();

?>