<?php
class parents
{
	function parentsfun()
	{
		echo " i am the function of parents<br>";
	}
}
class child extends parents
{
	function childfun()
	{
		echo " i am function the child class<br>";
	}
}

$child=new child();
$child->childfun();
$child->parentsfun();

/*$c1=new parents();
$c1->parentsfun();*/
		
?>