<?php
class hello
{
	public $name ="Ajeet";
	public $email ="ajeetit6@gmail.com";
	public $mobile =7011495718;
	 function user()
	{
		echo "Name :".$this->name." "."Email :".$this->email." "."Mobile :".$this->mobile;
	}
}
$c1=new hello();
$c1->user();
?>