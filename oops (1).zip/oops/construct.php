<?php
class ABC
{
public $a;
public $b;

public function __construct()
//public function ABC()
	{
		echo "Automaitecally Called<br>";
	}
	
	public function a(){
	echo "A function<br>";
	}
}
$obj =new ABC();
$obj->a();
echo "<pre>";
print_r($obj);
?>