<?php
class food
{
	protected $fname;
	function getname($name)
	{
		$this->fname=$name;
	}
	function showdata()
	{
		echo "Item is:".$this->fname."<br>";
	}
}
class junkfood extends food
{
	private $jfname="Sandwich";
	function passvalue()
	{
		$this->fname="New junkfood";
	}
}
$jf=new junkfood();
$jf->passvalue();
$jf->showdata();
?>