<?php
class food
{
	private $fname;
    function getname($name)
	{
		$this->fname=$name; 
	}
	function showdata()
	{
		echo "Item is:".$this->fname."<br>";
	}
}
$f1= new food();
$f1->getname("Pizza");
$f1->showdata();
?>