<?php
class ABC
{
public $a;
public $b;

public function __construct($a,$b)
	{
		$this->a =$a;
		$this->b =$b;
	}
	
}
$obj =new ABC(10,20);

echo "<pre>";
print_r($obj);
?>