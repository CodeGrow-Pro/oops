<?php
class house
{
	public static $name ="Ajeet";
     function hello()
	{
		//echo "Hello World<br>";
		return self::$name;
	}
}
//echo house::$name;
echo house::hello();

?>