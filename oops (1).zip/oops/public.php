<?php
class food
{
	public $fname;
	function showdata()
	{
		echo "Item is"." ".$this->fname."<br>";
	}
}
$f1= new food();
$f1->fname="Pizza";
$f1->showdata();

?>